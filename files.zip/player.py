# player.py
# Handles everything about the player:
# creation, stats, inventory, skills, and equipped items.

from items import get_item, describe_item

# --- Class Definitions ---
# Each class is a dictionary of base stats and a list of skills.
# Skills are referenced by name and handled in combat.py.

CLASSES = {
    "1": {
        "name": "Warrior",
        "hp": 120,
        "max_hp": 120,
        "attack": 15,
        "defense": 10,
        "description": "Tough and hard-hitting. Built for the front line.",
        "skills": [
            {
                "name": "Power Strike",
                "description": "Deal 2x your attack as damage.",
                "cooldown": 3,
                "current_cooldown": 0,
                "type": "damage",
                "multiplier": 2.0,
            },
            {
                "name": "Shield Bash",
                "description": "Deal 1x attack and stun the enemy for 1 turn.",
                "cooldown": 4,
                "current_cooldown": 0,
                "type": "stun",
                "multiplier": 1.0,
            },
        ],
    },
    "2": {
        "name": "Rogue",
        "hp": 90,
        "max_hp": 90,
        "attack": 18,
        "defense": 6,
        "description": "Fast and precise. High damage, low defense.",
        "skills": [
            {
                "name": "Backstab",
                "description": "Deal 2.5x your attack as damage.",
                "cooldown": 4,
                "current_cooldown": 0,
                "type": "damage",
                "multiplier": 2.5,
            },
            {
                "name": "Smoke Bomb",
                "description": "Evade the next enemy attack entirely.",
                "cooldown": 5,
                "current_cooldown": 0,
                "type": "evade",
                "multiplier": 0,
            },
        ],
    },
    "3": {
        "name": "Mage",
        "hp": 80,
        "max_hp": 80,
        "attack": 20,
        "defense": 4,
        "description": "Powerful spells, fragile body. High risk, high reward.",
        "skills": [
            {
                "name": "Fireball",
                "description": "Deal 3x your attack as magic damage. Ignores defense.",
                "cooldown": 4,
                "current_cooldown": 0,
                "type": "magic",
                "multiplier": 3.0,
            },
            {
                "name": "Frost Shield",
                "description": "Reduce incoming damage by 50% for 2 turns.",
                "cooldown": 5,
                "current_cooldown": 0,
                "type": "shield",
                "multiplier": 0,
                "duration": 2,
            },
        ],
    },
}


def create_player():
    """Walk the player through character creation and return a player dict."""
    print("\n" + "=" * 50)
    print("  DUNGEON OF SHADOWS")
    print("=" * 50)
    print("\nEnter your character's name:")
    name = input("  > ").strip()
    if not name:
        name = "Adventurer"

    print("\nChoose your class:")
    for key, cls in CLASSES.items():
        print(f"  [{key}] {cls['name']} - {cls['description']}")
        print(f"       HP: {cls['hp']}  ATK: {cls['attack']}  DEF: {cls['defense']}")

    choice = ""
    while choice not in CLASSES:
        choice = input("\n  > ").strip()
        if choice not in CLASSES:
            print("  Pick 1, 2, or 3.")

    chosen = CLASSES[choice]

    # Build the player dict from the chosen class.
    # We do a deep copy of skills so cooldowns are independent per game.
    import copy
    player = {
        "name": name,
        "class": chosen["name"],
        "hp": chosen["hp"],
        "max_hp": chosen["max_hp"],
        "attack": chosen["attack"],
        "defense": chosen["defense"],
        "base_attack": chosen["attack"],
        "base_defense": chosen["defense"],
        "skills": copy.deepcopy(chosen["skills"]),
        "inventory": [],
        "weapon": None,   # currently equipped weapon
        "armor": None,    # currently equipped armor
        "gold": 0,
        "shield_turns": 0,     # tracks Frost Shield duration
        "evade_next": False,   # tracks Smoke Bomb evade
        "stunned": False,      # not used for player, but kept for symmetry
    }

    print(f"\nWelcome, {player['name']} the {player['class']}!")
    print("Your journey begins...\n")
    return player


def show_stats(player):
    """Print current player stats."""
    print("\n--- Player Stats ---")
    print(f"  Name  : {player['name']} the {player['class']}")
    print(f"  HP    : {player['hp']} / {player['max_hp']}")
    print(f"  Attack: {player['attack']}  Defense: {player['defense']}")
    weapon_name = player["weapon"]["name"] if player["weapon"] else "None"
    armor_name = player["armor"]["name"] if player["armor"] else "None"
    print(f"  Weapon: {weapon_name}")
    print(f"  Armor : {armor_name}")
    print(f"  Gold  : {player['gold']}")


def show_inventory(player):
    """Print player inventory."""
    print("\n--- Inventory ---")
    if not player["inventory"]:
        print("  (empty)")
        return
    for i, item in enumerate(player["inventory"]):
        print(f"  [{i + 1}] ", end="")
        describe_item(item)


def show_skills(player):
    """Print player skills and their cooldowns."""
    print("\n--- Skills ---")
    for i, skill in enumerate(player["skills"]):
        cd = skill["current_cooldown"]
        status = "Ready" if cd == 0 else f"Cooldown: {cd} turn(s)"
        print(f"  [{i + 1}] {skill['name']} ({status})")
        print(f"       {skill['description']}")


def pick_up_item(player, item):
    """Add an item to the player's inventory."""
    player["inventory"].append(item)
    print(f"  Picked up: {item['name']}")


def discard_item(player, index):
    """Remove an item from inventory by index (0-based)."""
    if index < 0 or index >= len(player["inventory"]):
        print("  Invalid item number.")
        return
    removed = player["inventory"].pop(index)
    print(f"  Discarded: {removed['name']}")


def equip_item(player, index):
    """Equip a weapon or armor from inventory."""
    if index < 0 or index >= len(player["inventory"]):
        print("  Invalid item number.")
        return

    item = player["inventory"][index]

    if item["type"] == "weapon":
        # Unequip current weapon back to inventory if any
        if player["weapon"]:
            player["inventory"].append(player["weapon"])
            print(f"  Unequipped: {player['weapon']['name']}")
        player["weapon"] = item
        player["inventory"].pop(index)
        # Recalculate attack
        player["attack"] = player["base_attack"] + item["attack_bonus"]
        print(f"  Equipped: {item['name']} (Attack now {player['attack']})")

    elif item["type"] == "armor":
        if player["armor"]:
            player["inventory"].append(player["armor"])
            print(f"  Unequipped: {player['armor']['name']}")
        player["armor"] = item
        player["inventory"].pop(index)
        player["defense"] = player["base_defense"] + item["defense_bonus"]
        print(f"  Equipped: {item['name']} (Defense now {player['defense']})")

    elif item["type"] == "consumable":
        print("  You cannot equip a consumable. Use it instead.")

    else:
        print("  Cannot equip that.")


def use_consumable(player, index):
    """Use a consumable item from inventory."""
    if index < 0 or index >= len(player["inventory"]):
        print("  Invalid item number.")
        return

    item = player["inventory"][index]

    if item["type"] != "consumable":
        print("  That item is not usable. Try equipping it instead.")
        return

    heal = item.get("heal_amount", 0)
    player["hp"] = min(player["hp"] + heal, player["max_hp"])
    player["inventory"].pop(index)
    print(f"  Used {item['name']}. Restored {heal} HP. HP is now {player['hp']}/{player['max_hp']}.")


def tick_cooldowns(player):
    """Reduce all skill cooldowns by 1 at the end of a turn."""
    for skill in player["skills"]:
        if skill["current_cooldown"] > 0:
            skill["current_cooldown"] -= 1


def is_alive(player):
    """Return True if the player is still alive."""
    return player["hp"] > 0
