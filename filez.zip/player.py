# player.py
# Player creation, stats, mana, inventory, skills, equip, and shop.

import copy
from items import get_item, describe_item, SHOP_CATALOG

# ---------------------------------------------------------------------------
# Class Definitions
# Each class has: hp, mana (mp), attack, defense, and 2-3 skills.
# Skills cost mana. No mana = no skills. Only items restore mana.
# ---------------------------------------------------------------------------

CLASSES = {
    "1": {
        "name": "Warrior",
        "hp": 130, "max_hp": 130,
        "mp": 60,  "max_mp": 60,
        "attack": 15, "defense": 10,
        "description": "Tough front-liner. Reliable damage, high survivability.",
        "skills": [
            {
                "name": "Power Strike",
                "description": "Deal 2x ATK as physical damage.",
                "mp_cost": 10,
                "type": "damage",
                "multiplier": 2.0,
            },
            {
                "name": "Shield Bash",
                "description": "Deal 1x ATK and stun the enemy for 1 turn.",
                "mp_cost": 15,
                "type": "stun",
                "multiplier": 1.0,
            },
            {
                "name": "War Cry",
                "description": "Boost your ATK by 5 for 3 turns.",
                "mp_cost": 20,
                "type": "buff_attack",
                "bonus": 5,
                "duration": 3,
            },
        ],
    },

    "2": {
        "name": "Rogue",
        "hp": 95,  "max_hp": 95,
        "mp": 70,  "max_mp": 70,
        "attack": 18, "defense": 6,
        "description": "Fast and precise. High damage, fragile body.",
        "skills": [
            {
                "name": "Backstab",
                "description": "Deal 2.5x ATK as physical damage.",
                "mp_cost": 12,
                "type": "damage",
                "multiplier": 2.5,
            },
            {
                "name": "Smoke Bomb",
                "description": "Evade the next enemy attack entirely.",
                "mp_cost": 15,
                "type": "evade",
                "multiplier": 0,
            },
            {
                "name": "Poison Blade",
                "description": "Deal 1x ATK and poison the enemy (5 dmg/turn for 3 turns).",
                "mp_cost": 18,
                "type": "poison",
                "multiplier": 1.0,
                "poison_dmg": 5,
                "poison_turns": 3,
            },
        ],
    },

    "3": {
        "name": "Mage",
        "hp": 80,  "max_hp": 80,
        "mp": 100, "max_mp": 100,
        "attack": 20, "defense": 4,
        "description": "Powerful magic, fragile body. Biggest mana pool.",
        "skills": [
            {
                "name": "Fireball",
                "description": "Deal 3x ATK as magic damage (ignores defense).",
                "mp_cost": 20,
                "type": "magic",
                "multiplier": 3.0,
            },
            {
                "name": "Frost Shield",
                "description": "Reduce all incoming damage by 50% for 2 turns.",
                "mp_cost": 15,
                "type": "shield",
                "duration": 2,
            },
            {
                "name": "Chain Lightning",
                "description": "Deal 2x ATK as magic damage twice (ignores defense).",
                "mp_cost": 25,
                "type": "magic_double",
                "multiplier": 2.0,
            },
        ],
    },
}


def create_player():
    """Walk the player through character creation and return a player dict."""
    print("\n" + "=" * 55)
    print("       DUNGEON OF SHADOWS")
    print("=" * 55)
    print("\nEnter your character's name:")
    name = input("  > ").strip() or "Adventurer"

    print("\nChoose your class:\n")
    for key, cls in CLASSES.items():
        print(f"  [{key}] {cls['name']}  -  {cls['description']}")
        print(f"       HP: {cls['hp']}  MP: {cls['mp']}  ATK: {cls['attack']}  DEF: {cls['defense']}")
        print(f"       Skills: {', '.join(s['name'] for s in cls['skills'])}\n")

    choice = ""
    while choice not in CLASSES:
        choice = input("  Pick a class (1/2/3): ").strip()

    chosen = CLASSES[choice]
    player = {
        "name": name,
        "class": chosen["name"],
        "hp": chosen["hp"],
        "max_hp": chosen["max_hp"],
        "mp": chosen["mp"],
        "max_mp": chosen["max_mp"],
        "attack": chosen["attack"],
        "defense": chosen["defense"],
        "base_attack": chosen["attack"],
        "base_defense": chosen["defense"],
        "skills": copy.deepcopy(chosen["skills"]),
        "inventory": [],
        "weapon": None,
        "armor": None,
        "gold": 0,
        # Combat state flags
        "shield_turns": 0,
        "evade_next": False,
        "attack_buff": 0,
        "attack_buff_turns": 0,
    }

    print(f"\n  Welcome, {player['name']} the {player['class']}!")
    print("  Your journey into the dungeon begins.\n")
    return player


# ---------------------------------------------------------------------------
# Display helpers
# ---------------------------------------------------------------------------

def show_stats(player):
    print("\n--- Player Stats ---")
    print(f"  {player['name']} the {player['class']}")
    print(f"  HP : {player['hp']} / {player['max_hp']}")
    print(f"  MP : {player['mp']} / {player['max_mp']}")
    eff_atk = player["attack"] + player.get("attack_buff", 0)
    print(f"  ATK: {eff_atk}  DEF: {player['defense']}")
    print(f"  Weapon: {player['weapon']['name'] if player['weapon'] else 'None'}")
    print(f"  Armor : {player['armor']['name'] if player['armor'] else 'None'}")
    print(f"  Gold  : {player['gold']}")


def show_inventory(player):
    print("\n--- Inventory ---")
    if not player["inventory"]:
        print("  (empty)")
        return
    for i, item in enumerate(player["inventory"]):
        print(f"  [{i + 1}] ", end="")
        describe_item(item)


def show_skills(player):
    print("\n--- Skills ---")
    for i, skill in enumerate(player["skills"]):
        cost = skill["mp_cost"]
        affordable = "OK" if player["mp"] >= cost else "NO MP"
        print(f"  [{i + 1}] {skill['name']}  (MP Cost: {cost}) [{affordable}]")
        print(f"       {skill['description']}")


# ---------------------------------------------------------------------------
# Inventory actions
# ---------------------------------------------------------------------------

def pick_up_item(player, item):
    player["inventory"].append(item)
    print(f"  Picked up: {item['name']}")


def discard_item(player, index):
    if not _valid_index(player["inventory"], index):
        return
    removed = player["inventory"].pop(index)
    print(f"  Discarded: {removed['name']}")


def equip_item(player, index):
    if not _valid_index(player["inventory"], index):
        return
    item = player["inventory"][index]

    if item["type"] == "weapon":
        if player["weapon"]:
            player["inventory"].append(player["weapon"])
            print(f"  Unequipped: {player['weapon']['name']}")
        player["weapon"] = player["inventory"].pop(index)
        player["attack"] = player["base_attack"] + player["weapon"]["attack_bonus"]
        print(f"  Equipped: {player['weapon']['name']}  (ATK now {player['attack']})")

    elif item["type"] == "armor":
        if player["armor"]:
            player["inventory"].append(player["armor"])
            print(f"  Unequipped: {player['armor']['name']}")
        player["armor"] = player["inventory"].pop(index)
        player["defense"] = player["base_defense"] + player["armor"]["defense_bonus"]
        print(f"  Equipped: {player['armor']['name']}  (DEF now {player['defense']})")

    else:
        print("  You can't equip that. Use consumables with 'use <number>'.")


def use_consumable(player, index):
    if not _valid_index(player["inventory"], index):
        return
    item = player["inventory"][index]
    if item["type"] != "consumable":
        print("  That item is not a consumable. Try 'equip <number>'.")
        return
    _apply_consumable(player, item)
    player["inventory"].pop(index)


def use_consumable_in_combat(player, index):
    """Same as use_consumable but returns True on success so combat can track the turn."""
    if not _valid_index(player["inventory"], index):
        return False
    item = player["inventory"][index]
    if item["type"] != "consumable":
        print("  That item is not a consumable.")
        return False
    _apply_consumable(player, item)
    player["inventory"].pop(index)
    return True


def _apply_consumable(player, item):
    hp_gain = item.get("heal_hp", 0)
    mp_gain = item.get("heal_mp", 0)
    if hp_gain > 0:
        actual = min(hp_gain, player["max_hp"] - player["hp"])
        player["hp"] += actual
        print(f"  Used {item['name']}. Restored {actual} HP.  HP: {player['hp']}/{player['max_hp']}")
    if mp_gain > 0:
        actual = min(mp_gain, player["max_mp"] - player["mp"])
        player["mp"] += actual
        print(f"  Used {item['name']}. Restored {actual} MP.  MP: {player['mp']}/{player['max_mp']}")
    if hp_gain == 0 and mp_gain == 0:
        print(f"  Used {item['name']}. Nothing happened.")


# ---------------------------------------------------------------------------
# Shop
# ---------------------------------------------------------------------------

def open_shop(player):
    print("\n" + "=" * 45)
    print("  TRAVELING MERCHANT")
    print(f"  Your gold: {player['gold']}")
    print("=" * 45)
    print("  What would you like to buy?\n")

    for i, entry in enumerate(SHOP_CATALOG):
        item = get_item(entry["item_id"])
        if item:
            print(f"  [{i + 1}] {item['name']}  -  {entry['price']}g  -  {item['description']}")

    print("  [0] Leave shop\n")
    choice = input("  > ").strip()

    if choice == "0" or not choice.isdigit():
        print("  You leave the merchant.")
        return

    idx = int(choice) - 1
    if idx < 0 or idx >= len(SHOP_CATALOG):
        print("  Invalid selection.")
        return

    entry = SHOP_CATALOG[idx]
    item = get_item(entry["item_id"])
    if player["gold"] < entry["price"]:
        print(f"  Not enough gold. You need {entry['price']}g.")
        return

    player["gold"] -= entry["price"]
    player["inventory"].append(item)
    print(f"  Bought {item['name']} for {entry['price']}g.  Gold remaining: {player['gold']}")


# ---------------------------------------------------------------------------
# Combat state helpers
# ---------------------------------------------------------------------------

def tick_combat_state(player):
    """Call at end of each combat turn to tick buff durations."""
    if player.get("shield_turns", 0) > 0:
        player["shield_turns"] -= 1

    if player.get("attack_buff_turns", 0) > 0:
        player["attack_buff_turns"] -= 1
        if player["attack_buff_turns"] == 0:
            player["attack_buff"] = 0
            print("  Your War Cry buff fades.")


def is_alive(player):
    return player["hp"] > 0


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _valid_index(lst, index):
    if index < 0 or index >= len(lst):
        print("  Invalid number.")
        return False
    return True
